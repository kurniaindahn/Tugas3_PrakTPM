package com.example.tugas3tpm;

public class Model {
    private String nama;
    private int img;


    public String getNama() {

        return nama;
    }

    public void setNama(String nama) {

        this.nama = nama;
    }

    public int getImg() {

        return img;
    }

    public void setImg(int img) {

        this.img = img;
    }
}
