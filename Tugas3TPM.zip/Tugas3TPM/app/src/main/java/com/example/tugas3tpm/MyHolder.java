package com.example.tugas3tpm;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    ImageView mImBendera;
    TextView mNama;
    Button bShare;
    ItemClickListener itemClickListener;



    MyHolder(@NonNull View itemView) {
        super(itemView);

        this.mImBendera = itemView.findViewById(R.id.benderaN);
        this.mNama = itemView.findViewById(R.id.namaN);

        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        this.itemClickListener.onItemClickListener(v, getLayoutPosition());
    }

    public void setItemClickListener(ItemClickListener ic) {
        this.itemClickListener = ic;
    }
}
