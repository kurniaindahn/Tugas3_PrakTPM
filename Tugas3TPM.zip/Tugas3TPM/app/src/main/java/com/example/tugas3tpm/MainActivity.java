package com.example.tugas3tpm;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    RecyclerView mRecyclerView;
    MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView = findViewById(R.id.recyclerView);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        myAdapter = new MyAdapter(this, getMyList());
        mRecyclerView.setAdapter(myAdapter);
    }
    private ArrayList<Model> getMyList() {

        ArrayList<Model> models = new ArrayList<>();

        Model m = new Model();
        m.setNama("Brunei Darussalam");
        m.setImg(R.drawable.brunei);
        models.add(m);

        m = new Model();
        m.setNama("Kamboja");
        m.setImg(R.drawable.cambodia);
        models.add(m);

        m = new Model();
        m.setNama("Indonesia");
        m.setImg(R.drawable.indonesia);
        models.add(m);

        m = new Model();
        m.setNama("Laos");
        m.setImg(R.drawable.laos);
        models.add(m);

        m = new Model();
        m.setNama("Malaysia");
        m.setImg(R.drawable.malaysia);
        models.add(m);

        m = new Model();
        m.setNama("Myanmar");
        m.setImg(R.drawable.myanmar);
        models.add(m);

        m = new Model();
        m.setNama("Filiphina");
        m.setImg(R.drawable.philippines);
        models.add(m);

        m = new Model();
        m.setNama("Singapura");
        m.setImg(R.drawable.singapore);
        models.add(m);

        m = new Model();
        m.setNama("Thailand");
        m.setImg(R.drawable.thailand);
        models.add(m);

        m = new Model();
        m.setNama("Vietnam");
        m.setImg(R.drawable.vietnam);
        models.add(m);

        return models;
    }
}