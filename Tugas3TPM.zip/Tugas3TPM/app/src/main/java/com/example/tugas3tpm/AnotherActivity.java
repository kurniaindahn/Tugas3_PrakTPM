package com.example.tugas3tpm;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class AnotherActivity extends AppCompatActivity {

    TextView mNamaN;
    ImageView mImBendera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_another);

        ActionBar actionBar = getSupportActionBar();

        mNamaN = findViewById(R.id.namaN);
        mImBendera = findViewById(R.id.imageView);

        Intent intent = getIntent();

        String mNama = intent.getStringExtra("iNama");

        byte[] mBytes = getIntent().getByteArrayExtra("iImage");

        Bitmap bitmap = BitmapFactory.decodeByteArray(mBytes, 0, mBytes.length);

        actionBar.setTitle(mNama);

        mNamaN.setText(mNama);
        mImBendera.setImageBitmap(bitmap);
    }
}
